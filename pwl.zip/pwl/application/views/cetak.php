<table border="1">
<tr>
    <td colspan=2><h3>Bukti Pendaftaran Mahasiswa Baru</h3></td>
</tr>
<tr>
    <td>Nama Lengkap</td>
    <td><?php echo $user->nama?></td>
</tr>
<tr>
    <td>Email</td>
    <td><?php echo $user->email?></td>
</tr>
<tr>
    <td>Nomor HP</td>
    <td><?php echo $user->hp?></td>
</tr>
<tr>
    <td>Alamat</td>
    <td><?php echo $user->alamat?></td>
</tr>
<tr>
    <td>Tanggal Daftar</td>
    <td><?php echo $user->tanggal_daftar?></td>
</tr>
</table>